package com.spring.mvc.controller;

public class Demo {
	private void mian() {
		int i=0;
	    int j=0;
	    for(i=1;i<=9;i++)
	    {   for(j=1;j<=9;j++)
	            System.out.print(i+"*"+j+"="+i*j+"\t");
	            System.out.println();
	    }

	}
}
