package com.spring.mvc.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Test extends Thread {
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) {
		
	}

	public void outFile(HttpServletRequest request, HttpServletResponse response,String pn,String na) {
		// TODO Auto-generated method stub
		  //先模拟一个图形byte[]  
      byte[] b1 = null;
		try {			  
			b1 = getBytes("D:/XYTEST/YXGL/新源县/伊钢信用社/王丽654125198510221082//thumbnail_001-20170919_131513.jpg");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
      //存为文件  
		String url= request.getSession().getServletContext().getRealPath("/");
      try {
			buff2Image(b1,url+"/mediaImg/media/"+pn+"/"+na+".jpeg");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
 
      System.out.println("Hello World!");  


	}
	 static void buff2Image(byte[] b,String tagSrc) throws Exception  
     {  
		 File f=new File(tagSrc);
		 File fileParent = f.getParentFile(); 
		 if(!fileParent.exists()){ 
		  fileParent.mkdirs(); 
		 } 
         FileOutputStream fout = new FileOutputStream(f,true);  
         //将字节写入文件  
         fout.write(b);  
         fout.close();  
     }  
		public static byte[] getBytes(String filePath) {
			byte[] buffer = null;
			try {
				File file = new File(filePath);
				if (file.exists()) {
					FileInputStream fis = new FileInputStream(file);
					ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);
					byte[] b = new byte[1000];
					int n;
					while ((n = fis.read(b)) != -1) {
						bos.write(b, 0, n);
					}
					fis.close();
					bos.close();
					buffer = bos.toByteArray();
				} else {
					System.out.println("图片存储地址：\"" + filePath + "\"不存在");
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return buffer;
		}

}