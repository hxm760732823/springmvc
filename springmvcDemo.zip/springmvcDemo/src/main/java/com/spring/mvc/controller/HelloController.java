package com.spring.mvc.controller;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.mvc.util.ImageByteUtil;
import com.spring.mvc.util.Test;

@Controller
public class HelloController {

	  @RequestMapping(value = "/hello", method = RequestMethod.GET)
	  @ResponseBody
	  public void echartsToTargetAndqy(HttpServletRequest request,HttpServletResponse response) throws IOException {
		  //定义根路径
	        String rootPath = request.getRealPath("/");
	        //创建文件
	        File file = new File(rootPath+"temp_download");
	        //判断文件是否存在，如果不存在，则创建此文件夹
	        if(!file.exists()){
	            file.mkdir();
	        }
	        String name = "图片压缩包下载";
	        String fileName = name+new Date().getTime();
	        String zipFileName = fileName + ".zip";
	        File zipFile = null;
	        String path = rootPath + "temp_download";

	        //调用工具类获取图片
	        byte[] data = ImageByteUtil.image2byte("http://h.hiphotos.baidu.com/image/h%3D300/sign=ad9202a6ecfe9925d40c6f5004a95ee4/d53f8794a4c27d1e45a021a717d5ad6edcc438ca.jpg");
	        //new一个文件对象用来保存图片，默认保存当前工程根目录  
	        if(data != null){
	            File imageFile = new File(path+File.separator+fileName+".jpg");  
	            //创建输出流  
	            FileOutputStream outStream = new FileOutputStream(imageFile);  
	            //写入数据  
	            try {
					outStream.write(data);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}  
	            //关闭输出流  
	            try {
					outStream.close();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }

	        try {
	            /*
	             * 用JDK自带的zipentry压缩后，压缩包中的文件名中文乱码，故放弃此种方法，使用commons-compress-1.6.jar包
	             * ZipEntry zipEntry = new ZipEntry(new
	             * String(txtFile.getName().getBytes("GB2312"),"ISO-8859-1"));
	             * zos.putNextEntry(zipEntry); ZipOutputStream zos = new
	             * ZipOutputStream(zipFos); ZipEntry zipEntry = new ZipEntry(new
	             * String(txtFile.getName().getBytes("GB2312"),"ISO-8859-1")); zos.
	             * putNextEntry(zipEntry);
	             * zos.write(FileUtils.readFileToByteArray(txtFile)); zos.flush();
	             * zos.close();
	             */
	            //获取创建好的图片文件
	            File imageFile = new File(path+"/"+fileName+".jpg");
	            // 打成压缩包
	            zipFile = new File(path + "/" + zipFileName);
	            FileOutputStream zipFos = new FileOutputStream(zipFile);
	            ArchiveOutputStream archOut = new ArchiveStreamFactory().createArchiveOutputStream(ArchiveStreamFactory.ZIP, zipFos);
	            if (archOut instanceof ZipArchiveOutputStream) {
	                ZipArchiveOutputStream zos = (ZipArchiveOutputStream) archOut;
	                ZipArchiveEntry zipEntry = new ZipArchiveEntry(imageFile, imageFile.getName());
	                zos.putArchiveEntry(zipEntry);
	                zos.write(FileUtils.readFileToByteArray(imageFile));
	                zos.closeArchiveEntry();
	                zos.flush();
	                zos.close();
	            }

	            // 压缩完删除txt文件
	            if (imageFile.exists()) {
	                imageFile.delete();
	            }

	            // 输出到客户端
	            OutputStream out = null;
	            out = response.getOutputStream();
	            response.reset();
	            response.setHeader("Content-Disposition", "attachment;filename=" + new String(zipFileName.getBytes("GB2312"), "ISO-8859-1"));
	            response.setContentType("application/octet-stream; charset=utf-8");
	            response.setCharacterEncoding("UTF-8");
	            out.write(FileUtils.readFileToByteArray(zipFile));
	            out.flush();
	            out.close();

	            // 输出客户端结束后，删除压缩包
	            if (zipFile.exists()) {
	                zipFile.delete();
	            }
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (ArchiveException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	  }
	  @RequestMapping(value = "/test", method = RequestMethod.GET)
	  @ResponseBody
	  public void testImage(HttpServletRequest request,HttpServletResponse response,String pa,String na) throws IOException {
		  Test test=new Test();
		  test.outFile(request,response,pa,na);
	  }
}
