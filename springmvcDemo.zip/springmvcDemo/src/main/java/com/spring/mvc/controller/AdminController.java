package com.spring.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.util.FileUtil;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.mvc.util.ZipCompressorByAnt;

@Controller
public class AdminController {

	private String filePath = AdminController.class.getResource("/").getPath().split("WEB-INF")[0] + "upload/";

	@RequestMapping(value = "/export_zip", method = { RequestMethod.GET, RequestMethod.POST })
	public void zipwordDownAction(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 打包文件的存放路径
		ZipCompressorByAnt zc = new ZipCompressorByAnt(filePath + "/file.zip");
		// 需要打包的文件路径
		String url= request.getSession().getServletContext().getRealPath("/");
		zc.compress(url + "/mediaImg/");
		String contentType = "application/octet-stream";
		try {
			// 导出压缩包
			download(request, response, "upload/file.zip", contentType,
					encodeChineseDownloadFileName(request, "file.zip"));
		} catch (Exception e) {
			request.getSession().setAttribute("msg", "暂无内容");
		}
		// 如果原压缩包存在,则删除
		String path2= request.getSession().getServletContext().getRealPath("/");
		File file = new File(filePath + "/file.zip");
		if (file.exists()) {
			file.delete();
			delAllFile(path2 + "mediaImg");
		}
	}
	public static boolean delAllFile(String path) {  
	       boolean flag = false;  
	       File file = new File(path);  
	       if (!file.exists()) {  
	         return flag;  
	       }  
	       if (!file.isDirectory()) {  
	         return flag;  
	       }  
	       String[] tempList = file.list();  
	       File temp = null;  
	       for (int i = 0; i < tempList.length; i++) {  
	          if (path.endsWith(File.separator)) {  
	             temp = new File(path + tempList[i]);  
	          } else {  
	              temp = new File(path + File.separator + tempList[i]);  
	          }  
	          if (temp.isFile()) {  
	             temp.delete();  
	          }  
	          if (temp.isDirectory()) {  
	             delAllFile(path + "/" + tempList[i]);//先删除文件夹里面的文件  
	             delFolder(path + "/" + tempList[i]);//再删除空文件夹  
	             flag = true;  
	          }  
	       }  
	       return flag;  
	     }  
public static void delFolder(String folderPath) {  
    try {  
       delAllFile(folderPath); //删除完里面所有内容  
       String filePath = folderPath;  
       filePath = filePath.toString();  
       java.io.File myFilePath = new java.io.File(filePath);  
       myFilePath.delete(); //删除空文件夹  
    } catch (Exception e) {  
      e.printStackTrace();   
    }  
} 
	/**
	 * 下载文件
	 */
	public static void download(HttpServletRequest request, HttpServletResponse response, String storeName,
			String contentType, String realName) throws Exception {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;

		String ctxPath = FileUtil.class.getResource("/").getPath().split("WEB-INF")[0];
		String downLoadPath = ctxPath + storeName;

		long fileLength = new File(downLoadPath).length();

		response.setContentType(contentType);
		response.setHeader("Content-disposition",
				"attachment; filename=" + new String(realName.getBytes("utf-8"), "ISO8859-1"));
		response.setHeader("Content-Length", String.valueOf(fileLength));

		bis = new BufferedInputStream(new FileInputStream(downLoadPath));
		bos = new BufferedOutputStream(response.getOutputStream());
		byte[] buff = new byte[2048];
		int bytesRead;
		while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
			bos.write(buff, 0, bytesRead);
		}
		bis.close();
		bos.close();
	}

	/** 
     * 对文件流输出下载的中文文件名进行编码 屏蔽各种浏览器版本的差异性  
     */  
    public static String encodeChineseDownloadFileName(HttpServletRequest request, String pFileName) throws UnsupportedEncodingException {  
         String filename = null;    
            String agent = request.getHeader("USER-AGENT");    
            if (null != agent){    
                if (-1 != agent.indexOf("Firefox")) {//Firefox    
                    filename = "=?UTF-8?B?" + (new String(org.apache.commons.codec.binary.Base64.encodeBase64(pFileName.getBytes("UTF-8"))))+ "?=";    
                }else if (-1 != agent.indexOf("Chrome")) {//Chrome    
                    filename = new String(pFileName.getBytes(), "ISO8859-1");    
                } else {//IE7+    
                    filename = java.net.URLEncoder.encode(pFileName, "UTF-8");    
                    filename = StringUtils.replace(filename, "+", "%20");//替换空格    
                }    
            } else {    
                filename = pFileName;    
            }    
            return filename;   
    }
}